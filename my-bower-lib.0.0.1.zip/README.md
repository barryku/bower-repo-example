# packaged my-bower-lib

version: 0.0.1
web site: https://github.com/barryku/bower-repo-example